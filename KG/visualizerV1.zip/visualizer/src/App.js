// App.js
import React, { useEffect, useRef } from 'react';
import { Network } from 'vis-network/standalone';
import { DataSet } from 'vis-data';
import graphData from './data/machine_learning_graph.json';
import './App.css';

const App = () => {
    const networkContainerRef = useRef(null);
    const networkRef = useRef(null);

    // Process graph data to extract nodes
    const nodeMap = new Map();
    graphData.nodes.forEach(node => {
        if (node.id) {
            nodeMap.set(node.id, {
                id: node.id,
                type: node.type || 'subnode',
                description: node.description || '',
                parent: node.parent || null
            });
        }
    });

    // Infer nodes from relationships
    graphData.nodes.forEach(edge => {
        if (edge.from && edge.to) {
            if (!nodeMap.has(edge.from)) {
                nodeMap.set(edge.from, { id: edge.from, type: 'subnode', description: '' });
            }
            if (!nodeMap.has(edge.to)) {
                nodeMap.set(edge.to, { id: edge.to, type: 'subnode', description: '' });
            }
        }
    });

    // Function to get all subnodes recursively
    const getSubnodes = (nodeId, visited = new Set()) => {
        const subnodes = [];
        if (visited.has(nodeId)) return subnodes;
        visited.add(nodeId);

        graphData.nodes.forEach(edge => {
            if (edge.from === nodeId && edge.to !== nodeId) {
                subnodes.push(edge.to);
                subnodes.push(...getSubnodes(edge.to, visited));
            }
        });

        return [...new Set(subnodes)];
    };

    // Open subnode window
    const openSubnodeWindow = (nodeId) => {
        const subWindow = window.open('', '_blank');
        subWindow.document.write(`
            <html>
            <head>
                <title>${nodeId} Subnodes</title>
                <style>
                    body { margin: 0; height: 100vh; }
                    .subnetwork-container { height: 100%; width: 100%; }
                    .back-button { position: absolute; top: 10px; left: 10px; z-index: 10; padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
                    .back-button:hover { background-color: #45a049; }
                </style>
            </head>
            <body>
                <button class="back-button" onclick="window.close()">Close</button>
                <div class="subnetwork-container"></div>
                <script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
                <script>
                    const graphData = ${JSON.stringify(graphData)};
                    const nodeMap = new Map(${JSON.stringify([...nodeMap])});

                    function getSubnodes(nodeId, visited = new Set()) {
                        const subnodes = [];
                        if (visited.has(nodeId)) return subnodes;
                        visited.add(nodeId);
                        graphData.nodes.forEach(edge => {
                            if (edge.from === nodeId && edge.to !== nodeId) {
                                subnodes.push(edge.to);
                                subnodes.push(...getSubnodes(edge.to, visited));
                            }
                        });
                        return [...new Set(subnodes)];
                    }

                    const subnodes = ['${nodeId}', ...getSubnodes('${nodeId}')];
                    const nodesArray = subnodes.map(id => ({
                        id: id,
                        label: id,
                        title: nodeMap.get(id)?.description || '',
                        shape: id === '${nodeId}' ? 'box' : 'ellipse',
                        color: id === '${nodeId}' ? '#FF9999' : '#99CCFF',
                        font: { size: 14, color: '#000000' },
                        margin: 10
                    }));

                    const edgesArray = graphData.nodes
                        .filter(edge => subnodes.includes(edge.from) && subnodes.includes(edge.to))
                        .map(edge => ({
                            from: edge.from,
                            to: edge.to,
                            arrows: 'to',
                            color: '#000000',
                            title: edge.relationship
                        }));

                    const nodes = new vis.DataSet(nodesArray);
                    const edges = new vis.DataSet(edgesArray);

                    const options = {
                        interaction: { zoomView: true, dragView: true, hover: true },
                        nodes: { borderWidth: 2, size: 30, font: { align: 'center' } },
                        edges: { width: 2, smooth: { type: 'continuous' } },
                        layout: { randomSeed: 42, improvedLayout: true },
                        physics: {
                            enabled: true,
                            forceAtlas2Based: {
                                gravitationalConstant: -50,
                                centralGravity: 0.01,
                                springLength: 100,
                                springConstant: 0.08,
                                avoidOverlap: 1.5
                            },
                            minVelocity: 0.75,
                            solver: 'forceAtlas2Based'
                        }
                    };

                    const network = new vis.Network(document.querySelector('.subnetwork-container'), { nodes, edges }, options);
                    setTimeout(() => network.stopSimulation(), 2000);
                </script>
            </body>
            </html>
        `);
    };

    useEffect(() => {
        // Render main view: major nodes only
        const nodesArray = Array.from(nodeMap.values())
            .filter(node => node.type === 'major')
            .map(node => ({
                id: node.id,
                label: node.id,
                title: node.description,
                shape: 'box',
                color: '#FF9999',
                font: { size: 16, color: '#000000' },
                margin: 10
            }));

        const edgesArray = graphData.nodes
            .filter(edge => edge.from && edge.to && nodeMap.get(edge.from)?.type === 'major' && nodeMap.get(edge.to)?.type === 'major')
            .map(edge => ({
                from: edge.from,
                to: edge.to,
                arrows: 'to',
                color: '#000000',
                title: edge.relationship
            }));

        const nodes = new DataSet(nodesArray);
        const edges = new DataSet(edgesArray);

        const options = {
            interaction: { zoomView: true, dragView: true, hover: true },
            nodes: {
                borderWidth: 2,
                size: 30,
                font: { align: 'center' }
            },
            edges: {
                width: 2,
                smooth: { type: 'continuous' }
            },
            layout: { randomSeed: 42, improvedLayout: true },
            physics: {
                enabled: true,
                forceAtlas2Based: {
                    gravitationalConstant: -50,
                    centralGravity: 0.01,
                    springLength: 100,
                    springConstant: 0.08,
                    avoidOverlap: 1.5
                },
                minVelocity: 0.75,
                solver: 'forceAtlas2Based'
            }
        };

        const network = new Network(networkContainerRef.current, { nodes, edges }, options);
        networkRef.current = network;

        network.on('click', params => {
            if (params.nodes.length > 0) {
                const nodeId = params.nodes[0];
                if (nodeMap.get(nodeId)?.type === 'major') {
                    openSubnodeWindow(nodeId);
                }
            }
        });

        setTimeout(() => network.stopSimulation(), 2000);

        // Cleanup
        return () => {
            if (networkRef.current) {
                networkRef.current.destroy();
            }
        };
    }, []);

    return (
        <div className="app-container">
            <div ref={networkContainerRef} className="network-container" />
        </div>
    );
};

export default App;
